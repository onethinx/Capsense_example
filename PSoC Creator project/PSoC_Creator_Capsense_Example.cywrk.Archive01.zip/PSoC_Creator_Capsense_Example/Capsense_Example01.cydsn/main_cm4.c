/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    __enable_irq(); /* Enable global interrupts. */
    
    Cy_GPIO_Pin_FastInit(P12_4_PORT, P12_4_NUM, CY_GPIO_DM_STRONG, 0UL, HSIOM_SEL_GPIO);
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CapSense_Start();                           /* Initialize Component */
    CapSense_ScanAllWidgets();                  /* Scan all widgets */

    
    for(;;)
    {         /* Do this only when a scan is done */
        if(CapSense_NOT_BUSY == CapSense_IsBusy())         
        {
            CapSense_ProcessAllWidgets();       /* Process all widgets */
 
            if (CapSense_IsAnyWidgetActive())   /* Scan result verification */
            {       
                Cy_GPIO_Write(P12_4_PORT, P12_4_NUM, 1);
                /* add custom tasks to execute when touch detected */
            }
            else
                Cy_GPIO_Write(P12_4_PORT, P12_4_NUM, 0);
                
            CapSense_ScanAllWidgets();          /* Start next scan */
        }
    }
}

/* [] END OF FILE */
